# Standard Maps

- ``min.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/min.png)
- ``test.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/test.png)
- ``ghosts.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/ghosts.png)
- ``multipac.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/multipac.png)
- ``medium.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/medium.png)
- ``google.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/google.png)
- ``island.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/island.png)
- ``run.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/run.png)
- ``classic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/classic.png)

# Other Maps

- ``20Hunt.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/20Hunt.png)
- ``bigHunt.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/bigHunt.png)
- ``capsuleClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/capsuleClassic.png)
- ``classic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/classic2.png)
- ``contestClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/contestClassic.png)
- ``labAA1.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/labAA1.png)
- ``labAA2.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/labAA2.png)
- ``labAA3.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/labAA3.png)
- ``labAA4.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/labAA4.png)
- ``labAA5.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/labAA5.png)
- ``mediumClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/mediumClassic.png)
- ``mimapa.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/mimapa.png)
- ``minimaxClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/minimaxClassic.png)
- ``newmap.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/newmap.png)
- ``oneHunt.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/oneHunt.png)
- ``openClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/openClassic.png)
- ``openHunt.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/openHunt.png)
- ``originalClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/originalClassic.png)
- ``ourLayout.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/ourLayout.png)
- ``sixHunt.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/sixHunt.png)
- ``smallClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/smallClassic.png)
- ``smallHunt.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/smallHunt.png)
- ``testClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/testClassic.png)
- ``trappedClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/trappedClassic.png)
- ``trickyClassic.ber``

![img](https://raw.githubusercontent.com/madebypixel02/so_long/master/tests/map_img/trickyClassic.png)
